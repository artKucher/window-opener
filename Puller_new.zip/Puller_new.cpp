#include "Arduino.h"
// Outside of class
class Puller;

Puller *pointerToPullerClass;

static void outsideInterruptHandler(void) {
  pointerToPullerClass->pullerPositionChanged();
}

class Puller {
  public:
    using simpleCallback = void (*)(void);
    using parameterCallback = void (*)(int);
    
    void pullerPositionChanged(){
      _current_position_steps += _move_step;
    }
    
    
    Puller(int main_pinout, 
    int groud_pinout,
    int interrupt_pin,
    simpleCallback stop_notify,
    simpleCallback opening_notify,
    simpleCallback closing_notify,
    parameterCallback current_position_notify ) { 
      _groud_pinout = groud_pinout;
      _main_pinout = main_pinout;
      pinMode(_main_pinout, OUTPUT);
      pinMode(_groud_pinout, OUTPUT);
      
      pointerToPullerClass = this;
      pinMode(interrupt_pin, INPUT_PULLUP); 
      attachInterrupt(digitalPinToInterrupt(interrupt_pin), outsideInterruptHandler, CHANGE); 
      
      analogWriteFreq(100);
      
      _motion_in_progress = false;
      _current_position = 0;
      _move_step = 0;

      _stop_notify = stop_notify;
      _opening_notify = opening_notify;
      _closing_notify = closing_notify;
      _current_position_notify = current_position_notify;
    }

    
    void softStart() {
      }
    
    int move(int new_position){
      if (_current_position == new_position){
        _stop_notify();
      }
      if (_current_position < new_position){
        _opening_notify();
      }
      if (_current_position > new_position){
        _closing_notify();
      }
    }
    
    void motion_loop(){
      
    }
      
  private:
    int _current_position;
    int _current_position_steps;
    int _main_pinout;
    int _groud_pinout;
    bool _motion_in_progress;
    int _move_step;
    simpleCallback _stop_notify;
    simpleCallback _opening_notify;
    simpleCallback _closing_notify;
    parameterCallback _current_position_notify;
        
    void setBackwardDirection(){
      if (!_backward_direction){
        _backward_direction = true;
        
        int temp = _main_pinout;
        _main_pinout = _groud_pinout;
        _groud_pinout = temp;
      }
    }
    
    void setForwardDirection(){
      if (_backward_direction){
        _backward_direction = false;
        
        int temp = _main_pinout;
        _main_pinout = _groud_pinout;
        _groud_pinout = temp;
      }
    }
};
