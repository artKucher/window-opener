#include <Arduino.h>
#include <WiFiManager.h> 
#include <PubSubClient.h>

char mqtt_server[40];
int mqtt_port;
char mqtt_login[64];
char mqtt_password[64];
char mqtt_input_topic[256];
char mqtt_output_topic[256];

char* device_name = "WindowOpener";

WiFiManager wifiManager;
WiFiManagerParameter mqtt_server_param{"server", "mqtt server", mqtt_server, 40};
WiFiManagerParameter mqtt_port_param{"port", "mqtt port", "", 6};
WiFiManagerParameter mqtt_login_param{"login", "mqtt login", mqtt_login, 64};
WiFiManagerParameter mqtt_password_param{"password", "mqtt password", mqtt_password, 64};
WiFiManagerParameter mqtt_input_topic_param{"input topic", "mqtt input topic", mqtt_input_topic, 256};
WiFiManagerParameter mqtt_output_topic_param{"output topic", "mqtt output topic", mqtt_output_topic, 256};


WiFiClient espClient;
PubSubClient mqttClient(espClient);

void (*ComanderInit)();
void (*ComanderLoop)();
